//Guardo el nodo del elemento html
var elementoHtml = document.documentElement;
//Establecer event listeners a sus funciones
document.addEventListener("click", divAmarillo, true);
document.addEventListener("dblclick", divGris, true);
document.addEventListener("contextmenu", divVerde, true);



//Determinacion de la poscion del click del ratón
function posicionRaton(e) {
    var evento = e || window.event;
    var coordenadaX = evento.clientX;
    var coordenadaY = evento.clientY;

    return [coordenadaX, coordenadaY];
}

//Cuando se produzca el evento click...
function divAmarillo() {

    //Creacion del nodo "div" y llenarlo con el texto click y la posicion del raton
    var elDiv = document.createElement("div");
    var contenido = document.createTextNode("CLICK: " + posicionRaton()[0] + "," + posicionRaton()[1]);
    elDiv.appendChild(contenido);

    //Establecer las propiedades de estilo de este div
    elDiv.style.backgroundColor = "Yellow";
    elDiv.style.fontSize = "25px";
    elDiv.style.color = "red";
    elDiv.style.border = "red 1px solid"
    elDiv.style.position = "absolute";
    elDiv.style.top = posicionRaton()[1] + "px";
    elDiv.style.left = posicionRaton()[0] + "px";

    //Introduccion de nodo al documento html
    elementoHtml.appendChild(elDiv);
}

//Cuando se produzca el evento doubleclick...
function divGris() {

    //Creacion del nodo "div" y llenarlo con el texto click y la posicion del raton
    var elDiv = document.createElement("div");
    var contenido = document.createTextNode("CLICK: " + posicionRaton()[0] + "," + posicionRaton()[1]);
    elDiv.appendChild(contenido);

    //Establecer las propiedades de estilo de este div
    elDiv.style.backgroundColor = "lightgrey";
    elDiv.style.fontSize = "25px";
    elDiv.style.color = "red";
    elDiv.style.border = "red 1px solid"
    elDiv.style.position = "absolute";
    elDiv.style.top = posicionRaton()[1] + "px";
    elDiv.style.left = posicionRaton()[0] + "px";

    //Introduccion de nodo al documento html
    elementoHtml.appendChild(elDiv);
}

//Cuando se produzca el evento click derecho...
function divVerde() {

    //Creacion del nodo "div" y llenarlo con el texto click y la posicion del raton
    var elDiv = document.createElement("div");
    var contenido = document.createTextNode("CLICK: " + posicionRaton()[0] + "," + posicionRaton()[1]);
    elDiv.appendChild(contenido);

    //Establecer las propiedades de estilo de este div
    elDiv.style.backgroundColor = "lightgreen";
    elDiv.style.fontSize = "25px";
    elDiv.style.color = "red";
    elDiv.style.border = "red 1px solid"
    elDiv.style.position = "absolute";
    elDiv.style.top = posicionRaton()[1] + "px";
    elDiv.style.left = posicionRaton()[0] + "px";

    //Introduccion de nodo al documento html
    elementoHtml.appendChild(elDiv);

    //Para bloquear la apración del menú contextual
    window.oncontextmenu = function() {
        return false;
    }
}




/***************************************Otra forma de resolver el ejercicio***************************************/
/* 
function divPosicionRaton(e) {

    //Guardo el nodo del elemento html
    var elementoHtml = document.documentElement;

    //Determinacion de la poscion del click del ratón
    var evento = e || window.event;
    var coordenadaX = evento.clientX;
    var coordenadaY = evento.clientY;

    //Creacion del nodo "div" y llenarlo con el texto click y la posicion del raton
    var elDiv = document.createElement("div");
    var contenido = document.createTextNode("CLICK: " + coordenadaX + "," + coordenadaY);
    elDiv.appendChild(contenido);

    //Establecer las propiedades comunes de estilo de los div
    elDiv.style.fontSize = "25px";
    elDiv.style.color = "red";
    elDiv.style.border = "red 1px solid"
    elDiv.style.position = "absolute";
    elDiv.style.top = coordenadaY + "px";
    elDiv.style.left = coordenadaX + "px";


    //Dependiendo del tipo de evento se pinta de un color o otro, se introduce al documento y en el contexmenu se bloquea el menu
    if (evento.type == "click") {
        elDiv.style.backgroundColor = "Yellow";
        elementoHtml.appendChild(elDiv);

    } else if (evento.type == "dblclick") {
        elDiv.style.backgroundColor = "lightgrey";
        elementoHtml.appendChild(elDiv);
    } else if (evento.type == "contextmenu") {
        elDiv.style.backgroundColor = "lightgreen";
        elementoHtml.appendChild(elDiv);

        window.oncontextmenu = function() {
            return false;
        }

    }
}
//Al cargar toda la pagina establezco los event listeners a sus funciones
window.onload = function() {
    document.addEventListener("click", divPosicionRaton);
    document.addEventListener("dblclick", divPosicionRaton);
    document.addEventListener("contextmenu", divPosicionRaton);
} */