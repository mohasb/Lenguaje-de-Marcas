function inicio() {

    //String para guardar el valor del tamaño
    var tamanyo = "";
    //Obtencion del nodo de la hoja de estilo
    var estilo = document.getElementById("estilo");

    //Asignar el evento onresize al body
    document.getElementById("principal").onresize = inicio;

    //Dependiendo de la medida del ancho de la pagina se establece los diferentes .css y valores de tamaño
    if (window.innerWidth < 600) {
        estilo.href = "baja.css";
        tamanyo = "BAJA";
    } else if (window.innerWidth >= 600 && window.innerWidth < 1024) {
        estilo.href = "mediana.css";
        tamanyo = "MEDIANA"
    } else if (window.innerWidth >= 1024) {
        estilo.href = "alta.css";
        tamanyo = "ALTA"
    }
    //Escribo en el paragraph el valor del tamaño de la resolucion 
    document.getElementById("dades").innerHTML = "Resolucion de la pantalla:  " + tamanyo + ", " + window.innerWidth + " px";
}

window.onload = function() {
    inicio();
}