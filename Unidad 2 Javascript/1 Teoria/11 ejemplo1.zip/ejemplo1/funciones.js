function mostra() 
{
	var addicional = document.getElementById("addicional");
	addicional.className="visible";
	
	var link = document.getElementById("link");
	link.style.display="none";
}