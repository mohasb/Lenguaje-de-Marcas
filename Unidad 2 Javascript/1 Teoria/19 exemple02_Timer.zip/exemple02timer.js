function timer(){
	variableComptador=0;
	paragraf=document.getElementById("ultim")
	/** temporitzador, s'executa la funció comptador cada 1000 mil·lisegons ****/
	id = setInterval(comptador,1000);	
}
function comptador(){
	paragraf.innerHTML="Comptador: "+variableComptador
	/** incrementem el valor de la variable comptador ****/
	variableComptador=variableComptador+1
	if (variableComptador==5){
		/** quan arribem a 5, desactivem el temporitzador ****/
		clearInterval(id);
		/** Programem, una sola vegada, la funcio funcioFinal quan passen 3000 mil·lisegons *****/
		setTimeout(funcioFinal,3000)
	}
}

function funcioFinal(){
	alert("S'ha Acabat el comptador")
	/** reiniciem el temporitzador ****/
	//variableComptador=0;
	//id = setInterval(comptador,1000);	
}

window.onload=function(){	
	timer()
}