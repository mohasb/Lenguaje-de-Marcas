var elementosLista = document.getElementsByTagName("li");
console.log(elementosLista);
console.log(elementosLista[0]);

var elementosNombreTit = document.getElementsByName("tit");
console.log(elementosNombreTit);
console.log(elementosNombreTit[0]);

var lista = document.getElementById("listaPrincipal");
console.log(lista);
console.log(lista.id);
console.log(lista.className);

var elementoLista = document.createElement("li");
var contenido = document.createTextNode("Cuarto elemento");

elementoLista.appendChild(contenido);
lista.appendChild(elementoLista);
lista.removeChild(elementosLista[2]);

/* elementoLista.className = "elementoLista";
elementoLista.style.backgroundColor = "red"; */

var imagenAnimal = document.getElementById("imagenAnimal");
var src = imagenAnimal.getAttribute("src");
console.log(src);

imagenAnimal.setAttribute("src", "gato.jpg");
imagenAnimal.setAttribute("width", "400px");
imagenAnimal.setAttribute("height", "300px");

//lista.replaceChild(elementoLista, elementosLista[0]);
lista.insertBefore(elementoLista, elementosLista[0]);

function cambiarImagen(){
    var img = document.getElementById("imagenAnimal");
    var nombreFichero = img.getAttribute("src");

    if(nombreFichero == "perro.jpg")
    {
        img.setAttribute("src", "gato.jpg");
        /* img.setAttribute("width", "400px");
        img.setAttribute("height", "300px"); */
    }
    else if(nombreFichero == "gato.jpg")
    {
        img.setAttribute("src", "perro.jpg");
        /* img.setAttribute("width", "auto");
        img.setAttribute("height", "auto"); */
    }
}