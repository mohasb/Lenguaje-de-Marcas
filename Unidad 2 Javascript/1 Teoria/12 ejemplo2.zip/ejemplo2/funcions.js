function funcionsDOM(){
	/*************** Accés relatiu als nodes *******************/
	
	/*************** Accés a l'objecte html: ****************/
	/*var objecte_html = document.documentElement;
	objecte_html.style.padding="10px";
	objecte_html.style.backgroundColor="#CCC";
	objecte_html.style.borderStyle="solid";
	objecte_html.style.borderWidth="3px";
	objecte_html.style.borderColor="red";
		*/
	/*************** fills del document: ****************/
	/*var objecte_head = objecte_html.firstChild;
	//var objecte_body = objecte_html.lastChild;
	var objecte_body = objecte_html.childNodes[2];
	//var objecte_body = document.body;
	
	objecte_body.style.padding="10px";
	objecte_body.style.backgroundColor="#DDD";
	objecte_body.style.borderStyle="solid";
	objecte_body.style.borderWidth="3px";
	objecte_body.style.borderColor="red";
	*/
	/*************** Accés al nom del node: ****************/
	/*var nomNode = objecte_body.nodeName;
	paragraf.innerHTML=nomNode;
	var nomNode = paragraf.nodeName;
	paragraf.innerHTML=nomNode;
	*/
	/*************** Quantitat de fills de l'element  ****************/
	//sense ; també funciona
	/*	var nombreDescendents = objecte_html.childNodes.length
	//alert(nombreDescendents)
	//els elements de text compten com a fills.
	var element_p=objecte_body.childNodes[1];
	element_p.style.padding="10px";
	element_p.style.backgroundColor="#FF0";
	element_p.style.borderStyle="solid";
	element_p.style.borderWidth="3px";
	element_p.style.borderColor="blue";
	//element_p.style.color="red";
	*/
	
	/*************** següent germà del paràgraf ****************/
	/*altre_element_p=element_p.nextSibling.nextSibling;
	altre_element_p.style.padding="10px";
	altre_element_p.style.backgroundColor="#0FF";
	altre_element_p.style.borderStyle="solid";
	altre_element_p.style.borderWidth="3px";
	altre_element_p.style.borderColor="red";
	//noms i tipus de nodes
	//alert(nomNode+" - Tipus: "+paragraf.nodeType); // 1
	//var nomDocument = document.nodeName;
	//alert(nomDocument+" - Tipus: "+document.nodeType); // 9
	//var nomText = objecte_body.childNodes[2].nodeName;
	//alert(nomText+" - Tipus: "+objecte_body.childNodes[2].nodeType); // 3

	*/
	
	/*************** atributs ****************/
	/*var objecte_principal = document.getElementById("principal");
	var valor_name = objecte_principal.getAttribute("name"); // valor_name = "cos"
	paragraf.innerHTML="Atribut name de body: "+valor_name;
	objecte_principal.setAttribute("name", "noucos");	
	var valor_name = objecte_principal.getAttribute("name"); // valor_name = "noucos"
	paragraf.innerHTML="Atribut name de body: "+valor_name;
	*/
	
	
	/*************** Accés per etiqueta (tag) ****************/
	
	/*var paragrafs = document.getElementsByTagName("p");
	var primerParagraf = paragrafs[0];
	primerParagraf.style.padding="10px";
	primerParagraf.style.backgroundColor="#F0F";
	primerParagraf.style.borderStyle="solid";
	primerParagraf.style.borderWidth="3px";
	primerParagraf.style.borderColor="blue";
	
	//Recórrer tot l'array resultat
	for(var i=0; i<paragrafs.length; i++) {
		var paragraf = paragrafs[i];
		paragraf.style.borderStyle="solid";
		paragraf.style.borderWidth="3px";
		paragraf.style.borderColor="red";
	}*/
	
	
	/*************** Accés per id: ****************/
	
	/*var objecte_principal = document.getElementById("principal");
	objecte_principal.style.backgroundColor="#0FF";
	objecte_principal.style.borderStyle="solid";
	objecte_principal.style.borderWidth="3px";
	objecte_principal.style.borderColor="red";*/
	
	/*************** Accés per name: ****************/
	/*var objecte_ultim = document.getElementsByName("ultim");
	objecte_ultim[0].style.padding="10px";
	objecte_ultim[0].style.backgroundColor="#FF0";
	objecte_ultim[0].style.borderStyle="solid";
	objecte_ultim[0].style.borderWidth="3px";
	objecte_ultim[0].style.borderColor="blue";*/
	
	/***************  Eliminar un node ****************/
	/*var primer = document.getElementsByTagName("p")[0];
	document.body.removeChild(primer);*/
	
	//Eliminar un node amb parentChild
	/*var primer = document.getElementsByTagName("p")[0];
	primer.parentNode.removeChild(primer);
	
	
	//*************** Reemplaçar un node ****************
	
	var nouP = document.createElement("p");
	var text = document.createTextNode("Aquest paragraf s'ha creat dinamicament substitueix al paragraf original");
	nouP.appendChild(text);
	var anteriorP = document.body.getElementsByTagName("p")[0];
	anteriorP.parentNode.replaceChild(nouP, anteriorP);
	
	
	
	/******************** Inserir node abans *****************/
	
	/*var nouP = document.createElement("p");
	var text = document.createTextNode("Segon paragraf, abans del primer");
	nouP.appendChild(text);
	var anteriorP = document.getElementsByTagName("p")[0];
	document.body.insertBefore(nouP, anteriorP);*/
	
	/******************** Atributs *****************/
	// accedir als atributs
	/*
	var laImatge=document.getElementById("imatge")
	var atribut = laImatge.getAttribute("src");
	paragraf.innerHTML=atribut;

	// modificar els atributs
	laImatge.setAttribute("src", "img/coca.jpg");
	*/

	// Crear node de tipus Element
	//amb var variable local
	//sense var variable global                
	paragraf = document.createElement("p");
    
	// Crear node de tipus Text
	var contingut = document.createTextNode("Hola Món!");
    
	//Afegir el node de text a l'Element
	paragraf.appendChild(contingut);
    
	//paragraf.innerHTML="HOLA MÓN!";
	// Modificar característiques CSS de l'element
	//paragraf.style.height="50px";
	//paragraf.style.width="70%";
	//paragraf.style.marginLeft="auto";
	//paragraf.style.marginRight="auto";
	//paragraf.style.padding="10px";
	//paragraf.style.color="#FFF";
	//paragraf.style.fontFamily="Arial";
	//paragraf.style.fontSize="30px";
	//paragraf.style.fontWeight="bold";
	//paragraf.style.textAlign="center";
	//paragraf.style.backgroundColor="#00F";
	//paragraf.style.border="solid";	
	//paragraf.style.borderWidth="2px";	
	//paragraf.style.borderColor="#F00";
	//paragraf.style.borderBottomLeftRadius="20px";	
	//paragraf.style.borderTopRightRadius="20px";					
	// Afegir el node Element com a fill de la pagina
	document.body.appendChild(paragraf);

}