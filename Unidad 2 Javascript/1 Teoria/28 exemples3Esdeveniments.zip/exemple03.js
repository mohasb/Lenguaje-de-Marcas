function iniciar(){	

	var boto = document.getElementById("clicable");
	boto.onclick = mostraMissatge;

	document.onkeyup = mostraInformacio;
	document.onkeypress = mostraInformacio;
	document.onkeydown = mostraInformacio;
	
	//document.onkeypress = tecla;
}

/* funcions per a mostrar missatge al fer clic al botó*/
function mostraMissatge() {
  alert('Gràcies per clicar');
}

/* funcions per a mostrar informació de les tecles premudes*/
function mostraInformacio(lEsdeveniment) {
  var esdeveniment = window.event || lEsdeveniment;
  var info = document.getElementById("info");
  if(esdeveniment.altKey) {
	alert('Estava premuda la tecla ALT');
}
  var missatge = "Tipus d'esdeveniment: " + esdeveniment.type + "<br/>" +
				"Propietat keyCode: " + esdeveniment.keyCode + "<br/>" +
                "Propietat charCode: " + esdeveniment.charCode + "<br/>" +
                "Caràcter premut: " + String.fromCharCode(esdeveniment.charCode);
 
  info.innerHTML += "<br>--------------------------------------<br>" + missatge;
}


function tecla(lEsdeveniment) {
  var esdeveniment = lEsdeveniment || window.event;
  var caracter = esdeveniment.charCode || esdeveniment.keyCode;
  alert("El caràcter premut és: " + String.fromCharCode(caracter));
}
 

/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.onload=function(){	
	/*funció anònima*/
	iniciar();
}