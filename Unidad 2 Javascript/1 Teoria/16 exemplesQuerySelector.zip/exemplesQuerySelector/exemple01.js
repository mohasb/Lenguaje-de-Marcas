/* Exemple QuerySelector el primer fill de de #principal */
/*function ferclic(){
	document.querySelector('#principal p:first-child').onclick=mostraralerta;
}
function mostraralerta(){
	alert('has fet clic amb querySelector!');
}*/

/* Exemple QuerySelectorAll el primer fill de de #principal */
/* obtenim en una llista tots els elements p de #principal */
/* Però només activem el primer */
/*
function ferclic(){

var llista=document.querySelectorAll("#principal p");
llista[0].onclick=mostraralerta;
}
function mostraralerta(){
alert('has fet clic amb querySelectorAll!');
}
*/
/* Recorreguent tots els elements amb un bucle for */
/*
function ferclic(){
var llista=document.querySelectorAll("#principal p");
for(var f=0; f<llista.length; f++){
llista[f].onclick=mostraralerta;
  }
}
function mostraralerta(){
alert('ha fet clic amb querySelectorAll a qualsevol!');
}
*/
/* Combinant diferents funcions de selecció */

function ferclic(){
	var llista=document.getElementById("principal").querySelectorAll("p");
	llista[1].onclick=mostraralerta;
}

function mostraralerta(){
	alert('ha fet clic amb una combinaci\xf3 de selectors en el 2n par\xe0graf!');
}

window.onload=ferclic;
