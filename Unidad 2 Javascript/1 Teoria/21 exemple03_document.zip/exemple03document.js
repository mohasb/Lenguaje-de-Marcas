function funcioDocument(){
	paragrafLastModified=document.getElementById("lastModified");
	paragrafReferer=document.getElementById("referer");
	paragrafTitle=document.getElementById("title");
	paragrafURL=document.getElementById("URL");	
	botoInfo=document.getElementById("botoInfo");
	botoInfo.addEventListener("click",mostra,false);
	botoTitle=document.getElementById("botoTitle");
	botoTitle.addEventListener("click",canviaTitle,false);

}

function mostra(){
	paragrafLastModified.innerHTML="LastModified: "+document.lastModified;
	paragrafReferer.innerHTML="Referer: "+document.referer;
	paragrafTitle.innerHTML="Title: "+document.title;
	paragrafURL.innerHTML="URL: "+document.URL;	
}

function canviaTitle(){
	document.title="BOM";
}

window.onload=function(){	
	funcioDocument()
}