function iniciar(){	

	//document.onclick = mostraInformacio;
	//document.onclick = mostraInformacioPantallaCompleta;
	document.onclick = mostraInformacioOrigenPagina;
}

function mostraInformacioPantallaCompleta(lEsdeveniment) {
	var esdeveniment = lEsdeveniment || window.event;
	var info = document.getElementById("info");
	var coordenadaX = esdeveniment.screenX;
	var coordenadaY = esdeveniment.screenY;
	var missatge = "x: " + coordenadaX + "<br/>" +
				"y: " + coordenadaY + "<br/>";
	info.innerHTML += "<br>--------------------------------------<br>" + missatge;
}

function mostraInformacio(lEsdeveniment) {
  var esdeveniment = lEsdeveniment || window.event;
  var coordenadaX = esdeveniment.clientX;
  var coordenadaY = esdeveniment.clientY;
  alert("Has premut el ratolí en la posició: " + coordenadaX + ", " + coordenadaY);
}

function mostraInformacioOrigenPagina(lEsdeveniment) {
	var esdeveniment = lEsdeveniment || window.event;

	  coordenadaX = esdeveniment.pageX;
	  coordenadaY = esdeveniment.pageY;
	
	alert("Has premut el ratolí en la posició: " + coordenadaX + ", " + coordenadaY + " respecte de la pàgina web");
}

/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.onload=function(){	
	/*funció anònima*/
	iniciar();
}