function iniciar(){	

	paragrafs =["primer","segon","tercer","quart","cinque","sise","sete"]
	dies = ["Dilluns", "Dimarts", "Dimecres", "Dijous", "Divendres","Dissabte", "Diumenge"];
	cadena = "Parla'm, oh Musa, d'aquell home de multiforme enginy que, ...";

	var boto1 = document.getElementById("boto1");
	boto1.addEventListener("click",ex1,false);	
	var boto2 = document.getElementById("boto2");
	boto2.addEventListener("click",ex2,false);
	var boto3 = document.getElementById("boto3");
	boto3.addEventListener("click",ex3,false);
	var boto4 = document.getElementById("boto4");
	boto4.addEventListener("click",ex4,false);
	var boto5 = document.getElementById("boto5");
	boto5.addEventListener("click",ex5,false);
	var boto6 = document.getElementById("boto6");
	boto6.addEventListener("click",ex6,false);
	var boto7 = document.getElementById("boto7");
	boto7.addEventListener("click",ex7,false);


}




function ex1(){
		/*exemple switch*/

		var expr = prompt("Elegix una fruita");

		switch (expr) {
		  case "Taronges":
			nou_txt = "Taronges a 2€.";
			break;
		  case "Pomes":
			nou_txt = "Pomes a 1,2€.";
			break;
		  case "Bananes":
			nou_txt = "Bananes a 2,45€.";
			break;
		  case "Cireres":
			nou_txt = "Cireres a 6€.";
			break;
		  case "Mangos":
		  case "Papayes":
			nou_txt = "Mangos i papayes a 5,6€.";
			break;
		  default:
			nou_txt = "Ho sent molt, pero no tenim " + expr + ".";
		}

		var paragraf = document.getElementById(paragrafs[0]);
		var nou_span = document.createElement("span");

		var nou_node_txt = document.createTextNode(nou_txt);
		nou_span.style.marginLeft="10px";
		nou_span.style.fontWeight="bold";
		nou_span.style.fontFamily="arial";
		nou_span.style.color="white";

		nou_span.appendChild(nou_node_txt);
		paragraf.appendChild(nou_span);
}

function ex2(){

		var paragraf = document.getElementById(paragrafs[1]);

		for(i in dies) {
			var nou_span = document.createElement("span");
			var nou_node_txt = document.createTextNode(dies[i]);

			nou_span.style.marginLeft="10px";
			nou_span.style.fontWeight="bold";
			nou_span.style.fontFamily="arial";
			nou_span.style.color="white";

			nou_span.appendChild(nou_node_txt);
			paragraf.appendChild(nou_span);
		} 

}

function ex3(){

		var paragraf = document.getElementById(paragrafs[2]);

		var lletres = cadena.split("");
		var resultat = "";
		for(i in lletres) {
			if(lletres[i] == 'a') {
				break;
			}
			else {
				resultat += lletres[i];
			}
		}
		var nou_span = document.createElement("span");
		var nou_node_txt = document.createTextNode(resultat);

		nou_span.style.marginLeft="10px";
		nou_span.style.fontWeight="bold";
		nou_span.style.fontFamily="arial";
		nou_span.style.color="white";

		nou_span.appendChild(nou_node_txt);
		paragraf.appendChild(nou_span);

}

function ex4(){

		var paragraf = document.getElementById(paragrafs[3]);

		var lletres = cadena.split("");
		var resultat = "";
		for(i in lletres) {
			if(lletres[i] == 'a') {
				continue;
			}
			else {
				resultat += lletres[i];
			}
		}
		var nou_span = document.createElement("span");
		var nou_node_txt = document.createTextNode(resultat);

		nou_span.style.marginLeft="10px";
		nou_span.style.fontWeight="bold";
		nou_span.style.fontFamily="arial";
		nou_span.style.color="white";

		nou_span.appendChild(nou_node_txt);
		paragraf.appendChild(nou_span);

}



/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.addEventListener("load",iniciar,false);