function funcioLocation(){
	paragrafDades=document.getElementById("dades");	
	
	botoInfo=document.getElementById("botoInfo");
	botoInfo.addEventListener("click",mostra,false);
	botoAssign=document.getElementById("botoAssign");
	botoAssign.addEventListener("click",locationAssign,false);
	botoAssign=document.getElementById("botoReplace");
	botoAssign.addEventListener("click",locationReplace,false);
	botoLocation=document.getElementById("botoLocation");
	botoLocation.addEventListener("click",canviaLocation,false);
	botoReload=document.getElementById("botoReload");
	botoReload.addEventListener("click",recarrega,false);

}
function mostra(){
	var contingut="Host: "+location.host+"<br/>";
	contingut+="Hostname: "+location.hostname+"<br/>";
	contingut+="Hash: "+location.hash+"<br/>";
	contingut+="Href: "+location.href+"<br/>";
	contingut+="Pathname: "+location.pathname+"<br/>";
	contingut+="Port: "+location.port+"<br/>";
	contingut+="Protocol: "+location.protocol+"<br/>";
	contingut+="Search: "+location.search+"<br/>";
	paragrafDades.innerHTML=contingut;	
}

function locationAssign(){
	location.assign("http://www.imdb.com");
}
function locationReplace(){
	location.replace("http://www.iesperemaria.com");
}
function canviaLocation(){
	location.href="http://www.google.com";
}
function recarrega(){
	location.reload(true);
}

window.onload=function(){	
	funcioLocation()
}