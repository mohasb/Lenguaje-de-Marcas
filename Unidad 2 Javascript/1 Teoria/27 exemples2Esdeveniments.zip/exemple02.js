function iniciar(){	

	var boto = document.getElementById("clicable");
	boto.onclick = mostraMissatge;

	document.getElementById("seccio").onmouseover = ressalta;
	document.getElementById("seccio").onmouseout = ressalta;
}

/* funcions per a mostrar missatge al fer clic al botó*/
function mostraMissatge() {
  alert('Gràcies per clicar');
}
/*funció per a canviar el color de la vora dels paràgrafs */
function ressalta(lEsdeveniment) {
  var esdeveniment = lEsdeveniment || window.event;
  if(esdeveniment.type=='mouseover') {
      this.style.borderColor = 'black';
  }else if(esdeveniment.type=='mouseout'){
      this.style.borderColor = 'white';
  }
}


/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.onload=function(){	
	/*funció anònima*/
	iniciar();
}