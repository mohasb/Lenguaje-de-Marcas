function funcioScreen(){
	paragrafDades=document.getElementById("dades");	
	
	botoInfo=document.getElementById("botoInfo");
	botoInfo.addEventListener("click",mostra,false);

	botoCss=document.getElementById("botoCss");
	botoCss.addEventListener("click",cambiarCSS,false);
}
function mostra(){
	var contingut="availHeight: "+screen.availHeight+"<br/>";
	contingut+="availWidth: "+screen.availWidth+"<br/>";
	contingut+="colorDepth: "+screen.colorDepth+"<br/>";
	contingut+="pixelDepth: "+screen.pixelDepth+"<br/>";
	contingut+="height: "+screen.height+"<br/>";
	contingut+="width: "+screen.width+"<br/>";
		paragrafDades.innerHTML=contingut;	
}

function cambiarCSS(){
	var estilos = document.getElementById("estilos");

	console.log(estilos);

	if(window.innerWidth < 800){
		estilos.href = "baja.css"
	}
	else{
		estilos.href = "defecto.css"
	}
}

window.onload=function(){	
	funcioScreen()
}