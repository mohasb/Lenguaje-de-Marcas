function funcioNavigator(){
	paragrafDades=document.getElementById("dades");	
	
	botoInfo=document.getElementById("botoInfo");
	botoInfo.addEventListener("click",mostra,false);


}
function mostra(){
	var contingut="appCodeName: "+navigator.appCodeName+"<br/>";
	contingut+="appName: "+navigator.appName+"<br/>";
	contingut+="appMinorVersion: "+navigator.appMinorVersion+"<br/>";
	contingut+="appVersion: "+navigator.appVersion+"<br/>";
	contingut+="cookieEnabled: "+navigator.cookieEnabled+"<br/>";
	contingut+="cpuClass: "+navigator.cpuClass+"<br/>";
	contingut+="javaEnabled: "+navigator.javaEnabled+"<br/>";
	contingut+="language: "+navigator.language+"<br/>";
	contingut+="mimeTypes: "+navigator.mimeTypes+"<br/>";
	contingut+="online: "+navigator.online+"<br/>";
	contingut+="oscpu: "+navigator.oscpu+"<br/>";
	contingut+="platform: "+navigator.platform+"<br/>";
	contingut+="plugins: "+navigator.plugins+"<br/>";
	contingut+="product: "+navigator.product+"<br/>";
	contingut+="productSub: "+navigator.productSub+"<br/>";
	contingut+="systemLanguage: "+navigator.systemLanguage+"<br/>";
	contingut+="userAgent: "+navigator.userAgent+"<br/>";
	contingut+="userLanguage: "+navigator.userLanguage+"<br/>";
	paragrafDades.innerHTML=contingut;	
}



window.onload=function(){	
	funcioNavigator()
}