function iniciar(){		

	//Element formulari amb form[]
	//document.forms[0].style.padding="10px";
	//document.forms[0].style.backgroundColor="yellow";
	
	//Element dins del formulari amb form[].element[]
	//document.forms[0].elements[1].style.border="solid green 3px";
	//document.forms[0].elements[1].style.backgroundColor="cyan";
	
	//L'últim element del formulari
	//document.forms[0].elements[document.forms[0].elements.length-1].style.border="solid blue 3px";
	//document.forms[0].elements[document.forms[0].elements.length-1].style.backgroundColor="pink";
	
	//Accés al formulari amb name
	//document.formulari.style.border="dashed red 3px";
	
	//Accés al formulari per Id
	//document.getElementById("formulari").style.marginTop="50px";

	//establir el focus
	document.getElementById("text").focus();
	
	var botoenviar = document.getElementById("botoenviar");
	botoenviar.addEventListener("click",func_enviar,false);	

	var areatext = document.getElementById("paragraf");
	//areatext.addEventListener("keypress",func_areatext,false);
	areatext.addEventListener("keypress",limita,false);
	
	var campText = document.getElementById("text");
	campText.addEventListener("focus",focus_text,false);
	campText.addEventListener("blur",blur_text,false);

	
}


//funció per quan un camp obté el focus
function focus_text(lEsdeveniment){
	var esdeveniment = window.event || lEsdeveniment;
	esdeveniment.target.style.color="#CCC";
	esdeveniment.target.value="Escriu ací...";
	esdeveniment.target.style.color="#000";
	esdeveniment.target.style.border="solid blue 2px";
}
//funció per quan un camp deixa de tenir el focus
function blur_text(lEsdeveniment){
	var esdeveniment = window.event || lEsdeveniment;
	esdeveniment.target.style.border="solid black 2px";
}


function func_enviar(lEsdeveniment){
	var esdeveniment = window.event || lEsdeveniment;
	//esdeveniment.target.disabled=true;
	//esdeveniment.target.value="Enviant...";
	
	//comprovació dels valors dels camps
	
	//camp de text
	var valorText = document.getElementById("text").value;
	alert("Camp de text: "+valorText);
	
	//textarea
	var valorTextarea = document.getElementById("paragraf").value;
	alert("Textarea: "+valorTextarea);
	
	//botons de radio
	var botonsRadio = document.getElementsByName("pregunta");
 
	/*for(var i=0; i<botonsRadio.length; i++) {
	  alert(" Element Radio: " + botonsRadio[i].value + "\n Seleccionat: " + botonsRadio[i].checked);
	}
	*/
	
	//Quadres de check
	var quadreCheck = document.getElementById("condicions");
	alert(" Camp Check: " + quadreCheck.value + "\n Seleccionat: " + quadreCheck.checked);
	 
	quadreCheck = document.getElementById("privacitat");
	alert(" Camp Check: " + quadreCheck.value + "\n Seleccionat: " + quadreCheck.checked);
	
	
	//select
	// Obtenir la referència a la llista
	var llista = document.getElementById("opcions");
	
	// Obtenir l'índex de l'opció que s'ha seleccionat
	var indexSeleccionat = llista.selectedIndex;
	// Amab l'índex i l'array "options", obtenirr l'opció seleccionada
	var opcioSeleccionada = llista.options[indexSeleccionat];
	 
	// Obtenir el valor i el text de l'opció seleccionada
	var textSeleccionat = opcioSeleccionada.text; //el que es veu a la pàgina
	var valorSeleccionat = opcioSeleccionada.value; //el que s'envia amb el submit
	
	//abreujat:
	//var textSeleccionat = llista.options[llista.selectedIndex].text;
	//var valorSeleccionat = llista.options[llista.selectedIndex].value;
	 
	alert("Opció seleccionada: " + textSeleccionat + "\n Valor de l'opció: " + valorSeleccionat);
	
	//esdeveniment.target.form.submit();
}

function func_areatext(lEsdeveniment){
	var esdeveniment = window.event || lEsdeveniment;
	esdeveniment.preventDefault();
}

function limita(lEsdeveniment){
	var esdeveniment = window.event || lEsdeveniment;
	var areatext = document.getElementById("paragraf");
	var valor_limit=5;
	if(areatext.value.length >= valor_limit ) {
		esdeveniment.preventDefault();
	} else {
		return true;
	}
}


/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.addEventListener("load",iniciar,false);