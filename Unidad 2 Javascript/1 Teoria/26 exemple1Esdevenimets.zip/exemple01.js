function iniciar(){	
	/*document.getElementById("clicable").onclick = mostraMissatge2;*/
	var boto = document.getElementById("clicable");
	boto.onclick = mostraMissatge2;
	
	/*obtenim elements del formulari*/
	var formulari = document.getElementById("formulari");
	var campsInput = formulari.getElementsByTagName("input");
	/*assignem gestor al diferents inputs del formulari*/
	for(var i=0; i<campsInput.length; i++) {		
			campsInput[i].style.backgroundColor="#ff8080";
			campsInput[i].onclick = canviaVora;
			campsInput[i].onblur = tornaVora;
	}
}
/*funcions per a canviar el color de la vora dels inputs*/
function canviaVora(){
	this.style.borderColor='yellow';
}
function tornaVora(){
	this.style.borderColor='black';
}
/* funcions per a mostrar missatge al fer clic al botó*/
function mostraMissatge() {
  alert('Gràcies per clicar també');
}

function mostraMissatge2() {
  alert('Gràcies per clicar també ací');
}
/*funció per a canviar el color de la vora dels paràgrafs */
function ressalta(element) {
  if((element.style.borderColor=='silver') || (element.style.borderColor=='silver silver silver silver') || (element.style.borderColor=='#c0c0c0')) {

      element.style.borderColor = 'black';
  }
 else {
      element.style.borderColor = 'silver';
  } 
}

/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.onload=function(){	
	/*funció anònima*/
	iniciar();
}