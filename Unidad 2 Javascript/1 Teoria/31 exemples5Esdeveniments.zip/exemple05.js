function iniciar(){	

	var elDiv = document.getElementById("div_principal");
	elDiv.addEventListener("click", mostraMissatge, true);
	elDiv.addEventListener("click", mostraAltreMissatge, true);
	
	// Més endavant es decideix desassociar la funció a l'esdeveniment
// elDiv.removeEventListener("click", mostraMissatge, true);
	
	//Evitar que s'execute l'acció per defecte al fer clic
	//document.addEventListener("click", evitaAccioDefecte, true);
	

}

function evitaAccioDefecte(lEsdeveniment){
	lEsdeveniment.preventDefault();
}

//limita el nombre de caracters del textarea
function limita(maximCaracters) {
  var element = document.getElementById("text");
  if(element.value.length >= maximCaracters ) {
    return false;
  }
  else {
    return true;
  }
}

function mostraMissatge() {
  alert("Has premut el ratolí");
}
function mostraAltreMissatge() {
  alert("Has premut el ratolí i per açò es mostren aquests missatges");
}

/*funció per a executar-se quan s'acaba la càrrega de la pàgina*/
window.onload=function(){	
	/*funció anònima*/
	iniciar();
}