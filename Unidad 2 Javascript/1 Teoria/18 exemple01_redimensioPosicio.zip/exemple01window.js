function finestra(){
//Creem una nova finestra
//myWindow=window.open("", "Finestra", "width=400, height=200");
myWindow=window.open("http://www.iesperemaria.com", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=100,width=600,height=400");
// Redimensionar la finestra fins a una grandària de 600 x 250
//myWindow.resizeTo(600,250); 
// Moure la finestra 20 píxels cap a la dreta i 30 píxels cap a baix
myWindow.moveBy(20,30); 
// Augmentar l'altura de la finestra en 50 píxels
myWindow.resizeBy(0,50); 
// Col·locar la finestra en el cantó esquerre superior de la finestra
//myWindow.moveTo(0,0);
}

function posicio(){
alert('Pos X-screenX: '+myWindow.screenX+'\nPos Y-screenY: '+myWindow.screenY+
'\nPos X-screenLeft: '+myWindow.screenLeft+'\nPos Y-screenTop: '+myWindow.screenTop+
		'\nAmple Visible-innerWidth: '+myWindow.innerWidth+'\nAlt Visible-innerHeight: '+myWindow.innerHeight+
		'\nAmple-outerWidth: '+myWindow.outerWidth+'\nAlt-outerHeight: '+myWindow.outerHeight + '\nAmple Navegador-document.body.offsetWidth:'+ document.body.offsetWidth);

}

window.onload=function(){	
	finestra();
	posicio();
}