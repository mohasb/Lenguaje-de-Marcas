//Ejercicio 3.1

var edad = prompt("¿Cuantos años tienes?");

edadConducir();

function edadConducir() {

    if (edad >= 18) {
        alert("Ya puedes conducir");
    } else if (edad < 18) {
        alert("Aún no puedes conducir");
    }
}

//Ejercicio 3.2

var nota = prompt("¿Que nota has obtenido?");

calificacion(nota);

function calificacion(nota) {
    if (nota >= 0 && nota < 3) {
        alert("Su nota es: Muy deficiente");
    } else if (nota >= 3 && nota < 5) {
        alert("Su nota es: Insuficiente");
    } else if (nota >= 5 && nota < 6) {
        alert("Su nota es: Suficiente");
    } else if (nota >= 6 && nota < 7) {
        alert("Su nota es: Bien");
    } else if (nota >= 7 && nota < 9) {
        alert("Su nota es: Notable");
    } else if (nota >= 9 && nota < 10) {
        alert("Su nota es: Sobresaliente");
    }
}

//Ejercicio 3

var numero = prompt("Introduzca un numero y haré una pirámide");

piramide(numero);

function piramide(numero) {


    for (var i = 1; i <= numero; i++) {

        for (var j = 0; j < i; j++) {
            document.write(i);
        }
        document.write("<br>");
    }
}

//Ejercicio 4

var numero = prompt("Introduzca un numero y haré una pirámide invertida");

piramideInvertida(numero);

function piramideInvertida(numero) {
    for (var i = numero; i > 0; i--) {
        for (var j = 0; j < i; j++) {
            document.write(i)
        }
        document.write("<br/>")
    }
}

// Ejercicio 5

var texto = prompt("Escribe un texto y te lo devuelvo en mayusculas");

textoMayusculas(texto)

function textoMayusculas(texto) {
    alert(texto.toUpperCase())
}


//Ejercicio 6

var texto = prompt("Introduce un texto y te lo devuelvo al reves");

cadenaAlReves(texto);

function cadenaAlReves(texto) {

    var textoReves = texto.split("").reverse().join("");
    alert(textoReves);
}