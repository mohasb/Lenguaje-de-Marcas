//Ejercicio 1

var nombre = prompt("Ingrese su nombre:");
var edad = prompt("Ingrese su edad:");

document.write("Hola " + nombre + " tienes " + edad + " años.Bienvenido a mi Web");


//Ejercicio 2

var valor = 0;
var iva1 = 0.21;
var iva2 = 0.1;
var iva3 = 0.04;


var producto1 = new Object();
producto1.valor = 7.20;

var producto2 = new Object();
producto2.valor = 8.50;

var producto3 = new Object();
producto3.valor = 2.50;

var producto4 = new Object();
producto4.valor = 6.20;

var producto5 = new Object();
producto5.valor = 3.30;



var listaCompra1 = [producto1, producto2, producto3];
var listaCompra2 = [producto1, producto4, producto5];





function calculoIvaTotal() {

    var ivaTotal1 = 0;
    var ivaTotal2 = 0;


    ivaTotal1 = (producto1.valor * iva1) + (producto2.valor * iva2) + (producto3.valor * iva3);
    ivaTotal2 = (producto1.valor * iva1) + (producto4.valor * iva2) + (producto5.valor * iva3);

    console.log("El iva total de la lista de productos 1 = " + ivaTotal1 + "€");
    console.log("El iva total de la lista de productos 2 = " + ivaTotal2 + "€");

}

calculoIvaTotal();