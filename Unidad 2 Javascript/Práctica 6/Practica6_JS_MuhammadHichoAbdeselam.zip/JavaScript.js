/*****************Usando getElementById y/o getElementsByTagName********************/


//1- Acceso a un elemento cuya id es boton1
var boton = document.getElementById("boton1");
console.log(boton);

//2- Acceso a todos los párrafos de mi página
var todosP = document.getElementsByTagName("p");
console.log(todosP)

//3- Acceso a la primera tabla de mi página mediante el tag
var tablaTag = document.getElementsByTagName("table");
console.log(tablaTag[0])

//3- Acceso a la primera tabla de mi página mediante el ID
var tablaID = document.getElementById("primera");
console.log(tablaID)

//4- Acceso a todas las imagenes del section 
var section = document.body.childNodes[3];
var imagenesSection = section.getElementsByTagName("img")
console.log(imagenesSection)

//5- Acesso a la primera imagen dentro de un div cuya id es zonafotos
var primeraImg = document.getElementById("zonafotos").firstElementChild;
console.log(primeraImg);

//6- Acesso al tercer enlace del footer
var footer = document.body.childNodes[5];
var tercerlink = footer.getElementsByTagName("a");
console.log(tercerlink[2]);

/*****************Usando querySelector o querySelectorAll********************/

//1- Acceso a un elemento cuya id es boton1
var boton = document.querySelector("#boton1");
console.log(boton)

//2- Acceso a todos los párrafos de mi página
var todosP = document.querySelectorAll("p");
console.log(todosP)

//3- Acceso a la primera tabla de mi página
var tabla = document.querySelector("table");
console.log(tabla)

//4- Acceso a todas las imagenes del section 
var section = document.body.childNodes[3];
var imagenesSection = section.querySelectorAll("img");
console.log(imagenesSection);

//5- Acesso a la primera imagen dentro de un div cuya id es zonafotos
var primeraImg = document.querySelector("#zonafotos img")
console.log(primeraImg)

//6- Acesso al tercer enlace del footer
var footer = document.body.childNodes[5];
var tercerlink = footer.querySelectorAll("a")
console.log(tercerlink[2]);