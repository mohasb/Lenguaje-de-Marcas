var botonEnviar = document.getElementById("botonEnviar");
botonEnviar.addEventListener("click", validacion, false);
var elForm = document.getElementById("miformulario");

function validacion() {

    //Validacion campo nombre
    var nombre = elForm.nombre.value;

    if (nombre == null || nombre.length == 0 || /^\s+$/.test(nombre)) {
        //alert("Error!!\nEl nombre no puede estar vacío.")
        errNombre.innerHTML = "<br>" + "El nombre no puede estar vacío.";
        return false;
    } else {
        errNombre.innerHTML = "";
    }

    //Validacion campo edad
    var edad = elForm.edad.value;
    if (edad == null || edad.length == 0 || /^\s+$/.test(edad)) {
        //alert("Error!!\nLa edad no puede estar vacía.")
        errEdad.innerHTML = "<br>" + "La edad no puede estar vacía.";
        return false;
    } else {
        errEdad.innerHTML = "";
    }

    if (isNaN(edad)) {
        //alert("Error!!\nLa edad tiene que ser un número.");
        errEdad.innerHTML = "<br>" + "La edad tiene que ser un número.";
        return false;
    } else {
        errEdad.innerHTML = "";
    }

    //Validacion de los radioButton
    var provincia = elForm.provincia;
    var seleccionado = false;

    for (let i = 0; i < provincia.length; i++) {
        if (provincia[i].checked) {
            seleccionado = true;
            break;
        }
    }

    if (!seleccionado) {
        //alert("Error!!\nDebe seleccionarse una provincia.")
        errProvincia.innerHTML = "Debe seleccionarse una provincia."
        return false;
    } else {
        errProvincia.innerHTML = "";
    }

    //validacion menu desplegable
    var indiceSeleccionado = elForm.idioma.selectedIndex;

    if (indiceSeleccionado == null || indiceSeleccionado == 0) {
        //alert("Error!!\nDebe seleccionarse un idioma.")
        errIdioma.innerHTML = "Debe seleccionarse un idioma."
        return false;
    } else {
        errIdioma.innerHTML = ""
    }

    //Validacion checkbox
    var elemento = elForm.aceptar;

    if (!elemento.checked) {
        //alert("Error!!\nTienen que aceptarse las condiciones de uso.")
        errAcepta.innerHTML = "Tienen que aceptarse las condiciones de uso.";
        return false;
    } else {
        errAcepta.innerHTML = "";
    }

    console.log(nombre);
    console.log(document.forms[0].apellidos.value);
    console.log(edad);
    console.log(provincia.value);
    console.log(document.forms[0].idioma.options[indiceSeleccionado].value);
    console.log(elemento.value);

    func_enviar();




}

function func_enviar(elEvento) {
    var evento = window.event || elEvento;
    evento.target.disabled = true;
    evento.target.value = "Enviando...";
    evento.target.form.submit();
}