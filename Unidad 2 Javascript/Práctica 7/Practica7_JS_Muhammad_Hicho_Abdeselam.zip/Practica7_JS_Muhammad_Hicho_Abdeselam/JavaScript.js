function cambiaPagina() {
    var valor = confirm("¿Deseas cambiar de página?");
    var p = document.querySelector("p");

    if (valor == true) {

        p.innerHTML = "Vas a ser redirigido a w3schools en 4 segundos";
        setTimeout(nueva, 4000);

        function nueva() {
            window.open("https://www.w3schools.com/js/js_window.asp", "_self");
        }

    } else {
        p.innerHTML = "Has decidido quedarte";
    }
}

function otraPagina() {
    window.open("https://www.w3schools.com/js/js_window.asp", "_blanc").moveTo(0, 0)
}