function anyadir() {

    var etiqueta = document.createElement("li"); //Crear nodo elemento
    var contenido = document.createTextNode("Texto añadido al final de la lista"); //Crear nodo texto
    etiqueta.appendChild(contenido); //Establecer nodo texto hijo de nodo elemento
    document.getElementById("lista").appendChild(etiqueta) //Insetar nodo al final de la lista

}

function sustituir() {

    var nuevoTexto = document.createElement("li"); //Crear nodo elemento
    var contenido = document.createTextNode("Elemento sustituido de la segunda posicion de la lista") //Crear nodo texto
    nuevoTexto.appendChild(contenido); //Establecer nodo texto hijo de nodo elemento

    var segundoTexto = document.getElementsByTagName("li")[1]; //Guardar segundo nodo de la lista
    segundoTexto.parentNode.replaceChild(nuevoTexto, segundoTexto); //Insetar nodo sustituyendo el segundo elemento

}

function insertarAntes() {

    var nuevotexto = document.createElement("li"); //Crear nodo elemento
    var contenido = document.createTextNode("Texto insertado antes del tercer elemento") //Crear nodo texto
    nuevotexto.appendChild(contenido); //Establecer nodo texto hijo de nodo elemento

    var elTercero = document.getElementsByTagName("li")[02]; //Guardar nodo del tercer elemento
    elTercero.parentNode.insertBefore(nuevotexto, elTercero) //Insetar nodo antes del tercer elemento

}