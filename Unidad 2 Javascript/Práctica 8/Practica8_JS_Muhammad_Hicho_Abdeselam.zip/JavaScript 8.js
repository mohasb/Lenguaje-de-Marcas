function funcioDocument() {
    //Obtener nodo del paragraph
    pDatos = document.getElementById("datos");

    //Obtener nodo boton comprobar y establecer funcion comprobar a botonComprobar
    document.getElementById("botonComprobar").onclick = comprobar;

    //Obtener nodo boton baja y establecer funcion baja a botonBaja
    document.getElementById("botonBaja").onclick = baja;

    //Obtener nodo boton media y establecer funcion media a botonMedia
    document.getElementById("botonMedia").onclick = media;

    //Obtener nodo boton alta y establecer funcion alta a botonAlta
    document.getElementById("botonAlta").onclick = alta;

    //Obtener nodo del css
    estilo = document.getElementById("style");

}

function baja() {
    estilo.href = "baja.css";
}

function media() {
    estilo.href = "media.css";
}

function alta() {
    estilo.href = "alta.css";
}

function comprobar() {
    pDatos.innerHTML = "El ancho actual de la ventana es: " + window.innerWidth + " px" + "<br>";

    if (window.innerWidth <= 700) {
        estilo.href = "baja.css";
        pDatos.innerHTML += "Se ha establecido el .css de resolución BAJA"
    } else if (window.innerWidth > 700 && window.innerWidth <= 1000) {
        estilo.href = "media.css";
        pDatos.innerHTML += "Se ha establecido el .css de resolución MEDIA"
    } else if (window.innerWidth > 1000 && window.innerWidth <= 1536) {
        estilo.href = "alta.css";
        pDatos.innerHTML += "Se ha establecido el .css de resolución ALTA"
    }
}

window.onload = function() {
    funcioDocument()
}