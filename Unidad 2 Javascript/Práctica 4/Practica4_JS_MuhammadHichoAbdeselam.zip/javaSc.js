/*var precio = 0;
var iva = [];
var ivaTotal = 0;

var iva = [0.04, 0.1, 0.21];
var productos = [];

class producto {


    constructor(precio, iva) {

        this.precio = precio;
        this.iva = iva;
    }

}

var uno = new producto();
uno.precio = 3.14;
uno.iva[0];
var dos = new producto();
dos.precio = 8.57;
uno.iva[1];
var tres = new producto();
tres.precio = 4.98;
uno.iva[2];
var cuatro = new producto();
cuatro.precio = 1.33;
var cinco = new producto();
cinco.precio = 9.99;


class listaCompra {
    productos = [uno, dos, tres, cuatro, cinco];

}

function calcularIva() {
    for (let i = 0; i < productos.length; i++) {
        ivaTotal = productos[i].precio * iva[0];
        console.log(ivaTotal);
    }
}
*/

var precio = 0;
var iva = [0.04, 0.1, 0.21, 0.21, 0.1];
var ivaTotal;
var productos = [];

class producto {


    constructor(precio, iva) {

        this.precio = precio;
        this.iva = iva;
    }

}

var uno = new producto();
uno.precio = 3.14;
var dos = new producto();
dos.precio = 8.57;
var tres = new producto();
tres.precio = 4.98;
var cuatro = new producto();
cuatro.precio = 1.33;
var cinco = new producto();
cinco.precio = 9.99;

var productos = [uno, dos, tres, cuatro, cinco]



class ListaCompra {

    constructor(productos) {
        this.productos = productos;
    }
    calcularIva() {
        var total = 0;
        for (var i = 0; i < this.productos.length; i++) {
            total = total + (this.productos[i].precio * iva[i]);

        }
        return total;
    }
}

const listaCompra1 = new ListaCompra([productos[0], productos[1], productos[2]]);
const listaCompra2 = new ListaCompra([productos[3], productos[4], productos[0], productos[1]]);
const listaCompra3 = new ListaCompra([productos[2], productos[3]]);

console.log(listaCompra1.calcularIva());
console.log(listaCompra2.calcularIva());
console.log(listaCompra3.calcularIva());