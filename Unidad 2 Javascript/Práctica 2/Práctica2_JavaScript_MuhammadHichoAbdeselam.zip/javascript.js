//Ejercicio 3

var meses = ["Enero", " Febrero", " Marzo", " Abril", " Mayo", " Junio", " Julio", " Agosto", " Septiembre", " Octubre", " Noviembre", " Diciembre"];

alert("Meses del año: \n\n" + meses);

//Ejercicio 4

var valores = [true, 5, false, "hola", "adiós", 2];
var suma;
var resta;
var multiplicacion;
var division;
var resto;
var resultado;

//Ejercicio 4.1

if (valores[3].length > valores[4].length) {
    alert("1. El texto de la tercera posicion del array(\" hola \") es mayor; Tamaño: " + valores[3].length);
} else {
    alert("1. El texto de la cuarta posicion del array(\" adios \") es mayor; Tamaño: " + valores[4].length);

}
//Ejercicio 4.2

var valor1 = valores[0];
var valor2 = valores[2];

resultado = valor1 || valor2;
alert("El resultado de true || false es: " + resultado);

resultado = valor1 && valor2;
alert("El resultado de true && false es: " + resultado);

//Ejercicio 4.3

suma = valores[1] + valores[5];
resta = valores[1] - valores[5];
multiplicacion = valores[1] * valores[5];
division = valores[1] / valores[5];
resto = valores[1] % valores[5];

alert("3. Suma: " + suma + ", Resta: " + resta + ", Multiplicacion: " + multiplicacion + ", Division: " + division + ", Resto: " + resto);



//Ejercicio 5

var numero1 = 5;
var numero2 = 8;


if (numero1 < numero2) {
    alert("numero 1 no es mayor que numero 2");
}
if (numero2 > 0) {
    alert("numero2 es positivo");
}
if (numero1 < 0 && numero1 != 0) {
    alert("numero1 es negativo o distinto de 0");
}
if (numero1++ < numero2) {
    alert("Incrementar en 1 unidad el valor de numero1 no la hace mayor o igual que numero2");
}


//Ejercicio 6

var dni;
var letra;
var letraArray;
var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];


dni = prompt("Introduzca el número de DNI");


if (dni < 0 || dni > 99999999 || dni.length != 8) {
    alert("El numero proporcionado no es válido");
} else {

    letra = prompt("Introduzca la letra del DNI");
    letra.toUpperCase();

    numeroArray = [dni % 23];


    alert(letras[numeroArray]);
    alert(letra.toUpperCase());

    if (letras[numeroArray] == letra.toUpperCase()) {

        alert("El numero y la letra de DNI son correctos");
        alert("El DNI proporcionado es: " + dni + "\nLa letra porporcionada es : " + letra.toUpperCase() +
            "\nLa letra obtenida del programa es: " + letras[numeroArray]);


    } else {

        alert("Los datos introducidos no son correctos");
        alert("El DNI proporcionado es: " + dni + "\nLa letra porporcionada es : " + letra.toUpperCase() +
            "\nLa letra obtenida del programa es: " + letras[numeroArray]);
    }
}

//Ejercicio 7

var numero = 0;
var factorial = 1;

numero = prompt("Introduzca un numero y calcularé su factorial");

if (numero <= 0) {
    alert("Introduzca un numero positivo")
} else {
    for (var i = numero; i > 0; i--) {
        factorial *= i;
    }

    alert("El factorial de: " + numero + " es: " + factorial);
}