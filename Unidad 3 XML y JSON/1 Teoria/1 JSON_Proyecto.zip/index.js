class Persona{
    nombre = "";
    edad = "";
    profesion = "";
    coches = "";

    constructor(nombre, edad, profesion, coches){
        this.nombre = nombre;
        this.edad = edad;
        this.profesion = profesion;
        this.coches = coches;
    }
}

function crearPersona(event) {
    event.preventDefault();

    var nombre = document.getElementById("nombre").value;
    var edad = document.getElementById("edad").value;
    var profesion = document.getElementById("profesion").value;
    
    var cochesSeleccionaos = document.getElementById("coches").selectedOptions;
    var coches = Array.from(cochesSeleccionaos).map(({ value }) => value);

    var persona = new Persona(nombre, edad, profesion, coches);
    
    var json = JSON.stringify(persona);

    crearBin(json);
}

function crearBin(json){
    let req = new XMLHttpRequest();

    req.onreadystatechange = () => {
        if (req.readyState == XMLHttpRequest.DONE) {
            document.getElementById("estado").innerText = "Registro añadido!"
        }
    };

    req.open("POST", "https://api.jsonbin.io/v3/b", true);
    req.setRequestHeader("Content-Type", "application/json");
    req.setRequestHeader("X-Master-Key", SECRET_KEY);
    req.setRequestHeader("X-Collection-Id", COLLECTION_ID);
    req.send(json);
}

function leerColeccion() {
    let req = new XMLHttpRequest();

    req.onreadystatechange = () => {
        if (req.readyState == XMLHttpRequest.DONE) {
           respuesta = JSON.parse(req.responseText);

            for(var i = 0; i<respuesta.length; i++){
                leerBin(respuesta[i].record, false);
            }
        }
    };
    
    req.open("GET", "https://api.jsonbin.io/v3/c/" + COLLECTION_ID + "/bins/", true);
    req.setRequestHeader("X-Master-Key", SECRET_KEY);
    req.send();
}

function leerBin(binID, edicion) {
    let req = new XMLHttpRequest();

    req.onreadystatechange = () => {
        if (req.readyState == XMLHttpRequest.DONE) {
            if(!edicion){
                formatearPersonas(binID, JSON.parse(req.responseText).record);
            }
            else{
                cargarPersonaEdicion(JSON.parse(req.responseText).record);
            }
        }
    };

    req.open("GET", "https://api.jsonbin.io/v3/b/" + binID + "/latest", true);
    req.setRequestHeader("X-Master-Key", SECRET_KEY);
    req.send();
}

function formatearPersonas(binID, persona){
    //Obtención nodo principal
    var personas = document.getElementById("personas");

    //Creación de nodos
    var div_persona = document.createElement("div");
    
    var h2_nombre = document.createElement("h1");
    var p_edad = document.createElement("p");
    var p_profesion = document.createElement("p");
    var ul_coches = document.createElement("ul");

    var btn_editar = document.createElement("button");
    var btn_borrar = document.createElement("button");

    //Relleno de nodos
    h2_nombre.innerText = persona.nombre;
    p_edad.innerText = persona.edad;
    p_profesion.innerText = persona.profesion;

    for(var i = 0; i<persona.coches.length; i++)
    {
        var li = document.createElement("li");
        li.innerText = persona.coches[i]
        ul_coches.appendChild(li);
    }

    btn_editar.innerHTML = "<a href='editar.html'>Editar persona</a>"
    btn_borrar.innerText = "Borrar a: " + persona.nombre;

    //Eventos de editar y borrar
    btn_editar.addEventListener("click", function() { localStorage.setItem("binID",binID); }, false);
    btn_borrar.addEventListener("click", function() { borrarBin(binID); } ,false);

    //Adjuntamos nodos al div y al DOM
    div_persona.appendChild(h2_nombre);
    div_persona.appendChild(p_edad);
    div_persona.appendChild(p_profesion);
    div_persona.appendChild(ul_coches);

    div_persona.appendChild(btn_editar);
    div_persona.appendChild(btn_borrar);

    personas.appendChild(div_persona);
}

function cargarPersonaEdicion(persona){
    document.getElementById("nombre").value = persona.nombre;
    document.getElementById("edad").value = persona.edad;
    document.getElementById("profesion").value = persona.profesion;

    
    Array.from(document.getElementById("coches")).forEach(function (option) {
        option.selected = persona.coches.includes(option.value);
    });
}

function editarPersona(event, binID){
    event.preventDefault();

    var nombre = document.getElementById("nombre").value;
    var edad = document.getElementById("edad").value;
    var profesion = document.getElementById("profesion").value;
    
    var cochesSeleccionaos = document.getElementById("coches").selectedOptions;
    var coches = Array.from(cochesSeleccionaos).map(({ value }) => value);

    var persona = new Persona(nombre, edad, profesion, coches);
    
    var json = JSON.stringify(persona);

    editarBin(binID, json);
}

function editarBin(binID, persona) {
    let req = new XMLHttpRequest();

    req.onreadystatechange = () => {
        if (req.readyState == XMLHttpRequest.DONE) {
            document.getElementById("estado").innerText = "Registro actualizado!"
        }
    };

    req.open("PUT", "https://api.jsonbin.io/v3/b/" + binID, true);
    req.setRequestHeader("Content-Type", "application/json");
    req.setRequestHeader("X-Master-Key", SECRET_KEY);
    req.send(persona);
}

function borrarBin(binID) {
    var confirmacion = confirm("¿Desea borrar el registro?");

    if(confirmacion){
        let req = new XMLHttpRequest();
    
        req.onreadystatechange = () => {
            if (req.readyState == XMLHttpRequest.DONE) {
                limpiarPersonas();
                leerColeccion();
            }
        };
    
        req.open("DELETE", "https://api.jsonbin.io/v3/b/" + binID, true);
        req.setRequestHeader("X-Master-Key", SECRET_KEY);
        req.send();
    }
}

function limpiarPersonas(){
    var personas = document.getElementById("personas");
    personas.innerHTML = "";
}